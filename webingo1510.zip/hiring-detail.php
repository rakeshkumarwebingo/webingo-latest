<!DOCTYPE html>
<html lang="en" class="no-js">
  <head>
    <meta charset="utf-8"/>
   <title>Webingo | Best Web development company in Kolkata India</title>  
<meta name="description" content= "Best graphic designing, web development, app development and digital marketing solution in Kolkata India" />
<meta name="robots" content= "index, follow">
    <meta name="keywords" content="Best graphic designing, web development, app development and digital marketing solution">

		<meta property="og:image" content="https://webingo.in/images/white-logo.png" />
		<meta property="fb:app_id" content="666956320614810" />
		<meta property="og:url" content="https://webingo.in/index.php" />
		<meta property="og:title" content="Webingo | Best Web development company in Kolkata India" />

<meta name="author" content="Webingo">
    <!--website-favicon-->
    <link href="images/favicon.png" rel="icon">
    <!--plugin-css-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugin.min.css" rel="stylesheet">   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">   
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- template-style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	  <link href="css/sideform.css" rel="stylesheet">
	  <style>
		  @media (min-width: 320px) and (max-width: 765px){
   .hide {
         display:none;
	 }
			  
}
		  	  @media (min-width: 320px) and (max-width: 765px){
   .lm {
         margin-left: 0px;
	 }
			  
}
		  
	  </style>
  </head>
  <body>
       		<!--Start Header -->
		  
		 <?php include 'header.php'; ?>

  <!--Breadcrumb Area-->
 <!-- <section class="breadcrumb-area pink banner-2" style="padding-bottom: 0px">
    <div class="text-block">
      <div class="container">
        <div class="row">
          
            <div class="col-sm-6 col-xs-4 tabbanrt" >
				<div class="banner_pic">
					<picture>
						<h1 style="text-align: left;color: #fff;font-weight: 500">Software development from <strong>conception</strong> to <strong>delivery</strong></h1><hr>
						<h4  style="text-align: left;color: #fff;font-weight: 300">
							Sharing our <strong>expertise and passion</strong> to build <strong>solutions</strong> that <strong>empower your business</strong>				</h4>
					</picture>
				</div>
			</div>
			 <!--<div class="col-sm-3 col-xs-4 tabbanrt" style="margin-top: 4%">
				<div class="service-sec-list ">
					<img src="images/icons/tech.svg" alt="service">
					<h5 class="mb10" style="color: white">Trending Technologies</h5>
					<ul class="-service-list">
						<li > <a href="#" style="color: white">React.JS </a> </li>
						<li > <a href="#" style="color: white">Node.JS </a> </li>
						<li > <a href="#" style="color: white"> Angular.JS </a></li>
					</ul>
					<p style="color: white">Lorem Ipsum is text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p>
				 </div>   
			</div>-->
			<!--<div class="col-sm-2 col-xs-4 tabbanrt hide" style="margin-left: -97px;margin-right: 95px">
			  <svg class="svg1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 563.3 402.7" style="width: min-content;
    margin-top: 179px;">
				<g id="Layer_2" data-name="Layer 2">
				<g id="updated">
				<path id="DCSL_logo" class="cover-logo" d="M559.9,278.1c0.1-32.2-5.6-64.2-16.8-94.5c-1.3-3.2-2.4-6.8-4.1-10c-7.8-17-24.1-24.1-40-17.6
				s-23.5,22.7-16.8,40c10.4,26.8,16.2,54.2,16.2,82.1l0,0c0,11.6-9.4,21-21,21c-11.6,0-21-9.4-21-21l0,0c0.2-64.9,0-130,0-195.1
				c0-19.7-13.2-34.6-30.3-34.3c-17.6,0.3-30.3,14.1-30.5,34.1v61.7c-4.1-2.7-6-4.1-7.8-5.1c-37.3-27.9-79-38.9-125.5-34.9
				c-83.3,7-154.4,83.3-155.8,167.6c0,2,0,4.1,0,6.1h-0.1c0,11.5-9.4,20.9-20.9,20.9s-20.9-9.4-20.9-20.9l0,0
				c0-12.3,1.2-24.5,3.3-36.6C91,115.4,208.1,40,333,67.8c4.8,1.2,9.7,1.8,14.6,1.6c14.1-1.1,25.7-12.2,27.6-25.5
				c2.2-16.2-5.9-29.4-22.2-34C317.6-0.3,281.4-2.5,244.9,2.7C104.3,22.1,3.3,141.6,3.5,278.1H0v124.7h563.3V278.1H559.9z M280,391.5
				c-60.3-0.3-111.1-50.6-112.7-110.6l0,0c0-0.8,0-1.6,0-2.4c0-0.1,0-0.3,0-0.4l0,0c0-62.3,51.8-113.4,114.6-113.4
				S395.2,215,395.5,278.1l0,0c0,0.3,0,0.6,0,1c0,0.6,0,1.2,0,1.9l0,0C394.2,342.7,343.5,391.8,280,391.5z" style="fill:#f5f4f4"></path>
				</g>
				</g>
				</svg>
			</div>
				<div class="col-lg-4 col-xs-4 ">
				  <div class="itm-media-object lm ">
					<div class="media" >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-people.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">100+ software developers</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-uk-based.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">UK based, permanent employees</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-competitve.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Competitive day rates</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-blazing.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Rapid software delivery</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-awards.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Multi-award winning</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-cloud.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 "> Web, Mobile, Cloud & Desktop</h6>

					  </div>
					</div>

				  </div>
				</div>
          </div>
      </div>
    </div>
  </section>-->
	    <!--Breadcrumb Area-->
  
  <!--End Breadcrumb Area-->
  <!--End Breadcrumb-->  
<div class="single-page-header" data-background-image="images/single-job.jpg">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="single-page-header-inner">
					<div class="left-side">
						<div class="header-image"><a href="single-company-profile.html"><img src="images/company-logo-03a.png" alt=""></a></div>
						<div class="header-details">
							<h3> General Manager</h3>
							<h5>About the Employer</h5>
							<ul>
								<li><a href="single-company-profile.html"><i class="fas fa-home"></i> King</a></li>
								<li><div ><img src="images/footer-rating.png"></div></li>
								<li><img class="flag" src="images/flags/in.svg" alt="">Kolkata, India</li>
								<li><div class="verified-badge-with-title">✔ Verified</div></li>
							</ul>
						</div>
					</div>
					<div class="right-side">
						<div class="salary-box">
							<div class="salary-type">Annual Salary</div>
							<div class="salary-amount">₹35k - ₹38k</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<div class="background-image-container" style="background-image: url(&quot;images/single-job.jpg&quot;);"></div></div>
	  
	  <div class="container">
	<div class="row">
		
		<!-- Content -->
		<div class="col-xl-8 col-lg-8 content-right-offset">

			<div class="single-page-section">
				<h3 class="margin-bottom-25">Job Description</h3>
				<p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</p>

				<p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.</p>

				<p>Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.</p>
			</div>

			<div class="col-md-12 col-12 single-page-section">
				<h3 class="margin-bottom-30">Location</h3>
				<div id="single-job-map-container">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.2383470307113!2d88.43426211744384!3d22.570187200000007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0275abe402075f%3A0xee21c315a8eca0ad!2sWest%20Bengal%20Electronics%20Industry%20Development%20Corporation%20Limited!5e0!3m2!1sen!2sin!4v1599482227812!5m2!1sen!2sin" width="760" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					
				</div>
			</div>

			<div class="single-page-section">
				<h3 class="margin-bottom-25">Similar Jobs</h3>

				<!-- Listings Container -->
				<div class="listings-container grid-layout">

						<!-- Job Listing -->
						<a href="#" class="job-listing">

							<!-- Job Listing Details -->
							<div class="job-listing-details">
								<!-- Logo -->
								<div class="job-listing-company-logo">
									<img src="images/company-logo-02.png" alt="">
								</div>

								<!-- Details -->
								<div class="job-listing-description">
									<h4 class="job-listing-company">Webingo</h4>
									<h3 class="job-listing-title">Web Designer</h3>
								</div>
							</div>

							<!-- Job Listing Footer -->
							<div class="job-listing-footer">
								<ul>
									<li><i class="fas fa-map-marker-alt" style="line-height: 27px;"></i> San Francisco</li>
									<li><i class="fas fa-pen" style="line-height: 27px;"></i> Full Time</li>
									<li><i class="fas fa-wallet" style="line-height: 27px;"></i> ₹35000-₹38000</li>
									<li><i class="fas fa-clock" style="line-height: 27px;"></i> 2 days ago</li>
								</ul>
							</div>
						</a>

						<!-- Job Listing -->
						<a href="#" class="job-listing">

							<!-- Job Listing Details -->
							<div class="job-listing-details">
								<!-- Logo -->
								<div class="job-listing-company-logo">
									<img src="images/company-logo-03.png" alt="">
								</div>

								<!-- Details -->
								<div class="job-listing-description">
									<h4 class="job-listing-company">King <span class="verified-badge" data-tippy-placement="top" data-tippy="" data-original-title="Verified Employer"></span></h4>
									<h3 class="job-listing-title">Sofware Manager</h3>
								</div>
							</div>

							<!-- Job Listing Footer -->
							<div class="job-listing-footer">
								<ul>
									<li><i class="fas fa-map-marker-alt" style="line-height: 27px;"></i> San Francisco</li>
									<li><i class="fas fa-pen" style="line-height: 27px;"></i> Full Time</li>
									<li><i class="fas fa-wallet" style="line-height: 27px;"></i> ₹35000-₹38000</li>
									<li><i class="fas fa-clock" style="line-height: 27px;"></i> 2 days ago</li>
								</ul>
							</div>
						</a>
					</div>
					<!-- Listings Container / End -->

				</div>
		</div>
		

		<!-- Sidebar -->
		<div class="col-xl-4 col-lg-4">
			<div class="sidebar-container">

				<a href="#small-dialog" class="apply-now-button popup-with-zoom-anim">Apply Now <i class="icon-material-outline-arrow-right-alt"></i></a>
					
				<!-- Sidebar Widget -->
				<div class="sidebar-widget">
					<div class="job-overview">
						<div class="job-overview-headline">Job Summary</div>
						<div class="job-overview-inner">
							<ul>
								<li>
									<i class="fas fa-map-marker-alt"></i>
									<span>Location</span>
									<h5>London, United Kingdom</h5>
								</li>
								<li>
									<i class="fas fa-pen"></i>
									<span>Job Type</span>
									<h5>Full Time</h5>
								</li>
								<li>
									<i class="fas fa-wallet"></i>
									<span>Salary</span>
									<h5>₹35k - ₹38k</h5>
								</li>
								<li>
									<i class="fas fa-clock"></i>
									<span>Date Posted</span>
									<h5>2 days ago</h5>
								</li>
							</ul>
						</div>
					</div>
				</div>

				<!-- Sidebar Widget -->
			

			</div>
		</div>

	</div>
</div>
	 
	
	  
	
	
	 
	
<!--Start Footer-->
 <?php include 'footer.php'; ?>
<!--End Footer-->
<!--scroll to top-->
<a id="scrollUp" href="#top"></a>
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
		  <script>
		  $('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 250,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 5,
});
		  </script>	  
<script>
$(document).foundation();

// declare variables.
var $top_bar = $('.top-bar'),
    $menu_btn = $('#responsive-menu-btn');

// top bar sticky shrink class toggle.
$top_bar.on('sticky.zf.stuckto:top', function() {
  var $this = $(this);
  
  $this.addClass('shrink');
}).on('sticky.zf.unstuckfrom:top', function() {
  var $this = $(this);
  
  $this.removeClass('shrink');
})

// top bar responsive menu button context toggle.
$menu_btn.on('click', function(){
  $this = $(this);
  
  $this.toggleClass('alert').promise().done(function()
  {
    if ($this.hasClass('alert')) {
      $this.html('<i class="fa fa-md fa-times"></i> Close');
    } else {
      $this.html('<i class="fa fa-md fa-bars"></i> Menu');
    }
  });
});		  
</script>
	  <script>
    function isScrolledIntoView(elem)
    {
        var docViewTop = $(window).scrollTop();
        var docViewBottom = docViewTop + $(window).height();

        var elemTop = $(elem).offset().top;
        var elemBottom = elemTop + $(elem).height();
        // console.log((elemBottom <= docViewBottom));
        // console.log((elemTop >= docViewTop));

        return ((elemTop <= docViewBottom));
    }
    $(document).ready(function () {
      var elem=$('img.spinnnerImg');
      $(window).scroll(function(){
        $.each(elem,function(index,item){
          var check = isScrolledIntoView(item);
          if(check && $(item).attr('src') == 'images/spinner.gif'){
            setTimeout(function(){
              $(item).attr('src',$(item).data('src'));  
            },500);
          }
        })
        
      })
    })
  </script>
	  <script>
	  
    var offset = $('.form_box').offset(),

      setps = $('.steps'),

      new_steps = $('.new_steps'),

      form_wrapper = $('.form_wrapper'),

      form_box_width = $('.form_box').width(),

      // container width

      container = $('.form_wrapper').width(),

      // slide parent

      slideWrapper = $('.sliders'),

      // slides

      slide = $('.slide'),

      //thumbnail lists

      thumbnailList = $('.thumbnail'),

      count = 0;

    //end of variables    

    slideWrapper.width(container * slide.length);

    slide.width(container);

    setoffset = () => {
      
      $('.steps, .new_steps').width(slide.height());

      $('.steps').offset({ left: (offset.left + form_box_width), top: offset.top });

      $('.new_steps').offset({ left: offset.left - (thumbnailList.outerHeight() * $('.new_steps li').length), top: offset.top });

    };

    setoffset();

    // thumbnailList click

    thumbnailList.click(function (e) {

      count++;

      currentTarget = $(e.target);

      currentIndex = currentTarget.attr('data-index');

      currentTarget.toggleClass('move');

      if (currentTarget.hasClass('move')) {

        if (count != slide.length + 1)

          currentTarget.animate({ top: - form_wrapper.width() - currentTarget.outerHeight() * count }, 1000).addClass('disabled');

        slideWrapper.animate({ left: '-=' + container + 'px' }, 1000).find('.slide.active').removeClass('active').next().addClass('active');

        setTimeout(() => {

          currentTarget.animate({ top: 0 }, 0).prependTo('.get_thumbnail .new_steps');

          currentTarget.next().removeClass('disabled');

          setoffset();

        }, 1000);

      } else {

        // console.log(currentIndex * container);

        slideWrapper.animate({ left: - currentIndex * container }, 1000);

        $('.steps').stop().css('margin-left', '0');

        // currentTarget.animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        currentTarget.prevAll().animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        setTimeout(() => {

          currentTarget.prevAll().not('personalInfo').animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          // currentTarget.animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          currentTarget.addClass('disabled move');

          setoffset();

          count = currentIndex;

        }, 1000);

      }

    });
	  </script>
</body>
</html>